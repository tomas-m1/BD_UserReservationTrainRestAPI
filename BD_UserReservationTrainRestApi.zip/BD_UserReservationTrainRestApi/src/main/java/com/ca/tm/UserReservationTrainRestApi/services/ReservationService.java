package com.ca.tm.UserReservationTrainRestApi.services;

import com.ca.tm.UserReservationTrainRestApi.exceptions.RecordNotFoundException;
import com.ca.tm.UserReservationTrainRestApi.models.Reservation;
import com.ca.tm.UserReservationTrainRestApi.models.Train;
import com.ca.tm.UserReservationTrainRestApi.models.User;
import com.ca.tm.UserReservationTrainRestApi.repositories.ReservationRepository;
import com.ca.tm.UserReservationTrainRestApi.repositories.TrainRepository;
import com.ca.tm.UserReservationTrainRestApi.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TrainRepository trainRepository;

//    public Reservation createReservation(Long userId, Long trainId, Reservation reservation) {
//        User user = userRepository.findById(userId)
//                .orElseThrow(() -> new RecordNotFoundException("User not found"));
//
//        Train train = trainRepository.findById(trainId)
//                .orElseThrow(() -> new RecordNotFoundException("Train not found"));
//
//        reservation.setUser(user);
//        reservation.setTrain(train);

//        return reservationRepository.save(reservation);
//    }


    public Reservation createReservation(Reservation reservation) {
        reservation.setUser(reservation.getUser());
        reservation.setFromLocation(reservation.getFromLocation());
        reservation.setToLocation(reservation.getToLocation());
        reservation.setTrains(reservation.getTrains());
        return reservationRepository.save(reservation);
    }

    public Reservation updateReservation(Long id,Reservation reservation) {
        Reservation updatedReservation = reservationRepository.findById(id)
                .orElseThrow(() -> new RecordNotFoundException("Reservation not found"));
        return reservationRepository.save(updatedReservation);
    }

    public Reservation getReservationById(Long id) {
        return reservationRepository.findById(id)
                .orElseThrow(() -> new RecordNotFoundException("Reservation not found"));
    }

    public void deleteReservation(Long id) {
        Reservation reservation = reservationRepository.findById(id)
                .orElseThrow(() -> new RecordNotFoundException("Reservation not found"));

        reservationRepository.delete(reservation);
    }

    public List<Reservation> getAllReservations() {
        return (List<Reservation>) reservationRepository.findAll();
    }

//    public List<Train> getReservationTrains(Long reservationId) {
//        Reservation reservation = reservationRepository.findById(reservationId)
//                .orElseThrow(() -> new RecordNotFoundException("Reservation not found with id: " + reservationId));
//
//        return reservation.getTrains();
//    }
}
