package com.ca.tm.UserReservationTrainRestApi.controllers;

import com.ca.tm.UserReservationTrainRestApi.models.Reservation;
import com.ca.tm.UserReservationTrainRestApi.models.Train;
import com.ca.tm.UserReservationTrainRestApi.services.ReservationService;
import com.ca.tm.UserReservationTrainRestApi.services.TrainService;
import com.ca.tm.UserReservationTrainRestApi.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reservations")
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    @PostMapping
    public ResponseEntity<Reservation> createReservation(@RequestBody Reservation reservation) {
        Reservation createdReservation = reservationService.createReservation(reservation);
        return new ResponseEntity<>(createdReservation, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Reservation> updateReservation(@PathVariable Long id, @RequestBody Reservation reservation) {
        Reservation updatedReservation = reservationService.updateReservation(id, reservation);
        return new ResponseEntity<>(updatedReservation, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reservation> getReservationById(@PathVariable Long id) {
        Reservation reservation = reservationService.getReservationById(id);
        return new ResponseEntity<>(reservation, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReservation(@PathVariable Long id) {
        reservationService.deleteReservation(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping
    public ResponseEntity<List<Reservation>> getAllReservations() {
        List<Reservation> reservations = reservationService.getAllReservations();
        return new ResponseEntity<>(reservations, HttpStatus.OK);
    }

    //    @PostMapping("/{userId}/{id}")
//    public ResponseEntity<Reservation> createReservation(@PathVariable(value = "userId") Long userId,
//                                                         @PathVariable(value = "id") Long id,
//                                                         @RequestBody List<Long> trainIds) {
//        User user = userRepository.findById(userId)
//                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
//        Train train = trainRepository.findById(id)
//                .orElseThrow(() -> new ResourceNotFoundException("Train not found with id: " + id));
//
//        Reservation reservation = new Reservation();
//        reservation.setUser(user);
//        reservation.addTrain(train);
//
//        for (Long trainId : trainIds) {
//            Train t = trainRepository.findById(trainId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Train not found with id: " + trainId));
//            reservation.addTrain(t);
//        }
//
//        Reservation savedReservation = reservationService.saveReservation(reservation);
//
//        return ResponseEntity.ok(savedReservation);
//    }

//    @GetMapping("/{trainId}/reservations")
//    public ResponseEntity<List<Reservation>> getTrainReservations(@PathVariable Long trainId) {
//        List<Reservation> reservations = trainService.getTrainReservations(trainId);
//        return new ResponseEntity<>(reservations, HttpStatus.OK);
//    }
//    @GetMapping("/{id}/trains")
//    public ResponseEntity<List<Train> getReservationTrains(@PathVariable Long reservationId) {
//        List<Train> trains = reservationService.getReservationTrains(reservationId);
//        return new ResponseEntity<>(trains, HttpStatus.OK);
//    }

}
