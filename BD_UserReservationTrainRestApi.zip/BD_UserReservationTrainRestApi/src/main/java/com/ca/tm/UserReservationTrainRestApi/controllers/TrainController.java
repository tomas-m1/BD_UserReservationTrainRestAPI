package com.ca.tm.UserReservationTrainRestApi.controllers;

import com.ca.tm.UserReservationTrainRestApi.models.Reservation;
import com.ca.tm.UserReservationTrainRestApi.models.Train;
import com.ca.tm.UserReservationTrainRestApi.services.ReservationService;
import com.ca.tm.UserReservationTrainRestApi.services.TrainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/trains")
public class TrainController {

    @Autowired
    private TrainService trainService;

    @PostMapping
    public ResponseEntity<Train> createTrain(@RequestBody Train train) {
        Train createdTrain = trainService.createTrain(train);
        return new ResponseEntity<>(createdTrain, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Train> updateTrain(@PathVariable Long id, @RequestBody Train train) {
        Train updatedTrain = trainService.updateTrain(id, train);
        return new ResponseEntity<>(updatedTrain, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Train> getTrainById(@PathVariable Long id) {
        Train train = trainService.getTrainById(id);
        return new ResponseEntity<>(train, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTrain(@PathVariable Long id) {
        trainService.deleteTrain(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping
    public ResponseEntity<List<Train>> getAllTrains() {
        List<Train> trains = trainService.getAllTrains();
        return new ResponseEntity<>(trains, HttpStatus.OK);
    }

//    @GetMapping("/{trainId}/reservations")
//    public ResponseEntity<List<Reservation>> getTrainReservations(@PathVariable Long trainId) {
//        List<Reservation> reservations = trainService.getTrainReservations(trainId);
//        return new ResponseEntity<>(reservations, HttpStatus.OK);
//    }

}
